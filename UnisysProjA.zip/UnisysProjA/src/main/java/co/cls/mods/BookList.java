package co.cls.mods;

import java.util.List;
import java.util.ArrayList;

public class BookList {
	public List<Books> retList(){
		List<Books> ls=new ArrayList<Books>();
		int[] arr1= {1,2,3,4,5};
		String[] arr2= {"Adventures of tom sawyer","Kane and abel","elephant song","Pelican brief","God of small things"};
		String[] arr3= {"Mark twain","J Archer","Wilbur smith","John Grisham","Arundhati roy"};
		for (int i = 0; i < arr3.length; i++) {
			Books b=new Books();
			b.setBid(arr1[i]);
			b.setBname(arr2[i]);
			b.setBauth(arr3[i]);
			ls.add(b);
		}
		return ls;
	}
}
