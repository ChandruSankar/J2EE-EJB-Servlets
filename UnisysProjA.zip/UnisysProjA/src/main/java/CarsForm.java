

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.cls.mods.Cars;
import co.cls.mods.ListCars;

import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class CarsForm
 */
@WebServlet("/CarsForm")
public class CarsForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarsForm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    ListCars lca=new ListCars();
    List<Cars> lc=lca.retCList();
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.addHeader("content-type", "text/html");
		PrintWriter out=response.getWriter();
		String op="<center><h1>Car Entry Form</h1><br/><hr/><br/><form><table border=1><tr><td>Car Id</td><td><input type=text name=cid /></td></tr>";
		op+="<tr><td>Car Name</td><td><input type=text name=cname /></td></tr>";
		op+="<tr><td>Car Brand</td><td><input type=text name=cbrand /></td></tr>";
		op+="<tr><td><input type=submit value=Send /></td><td><input type=reset value=Cancel /></td></tr></table></form></center>";
		out.println(op+"<br/><hr/><br/>");
		if(request.getParameter("cname")!=null) {
			int a=Integer.parseInt(request.getParameter("cid"));
			String b=request.getParameter("cname");
			String c=request.getParameter("cbrand");
			Cars cc=new Cars();
			cc.setCid(a);
			cc.setCname(b);
			cc.setCbrand(c);
			lc.add(cc);
			out.println("<ul>");
			for(Cars ca:lc) {
				out.println("<li>"+ca.getCid()+"&nbsp;"+ca.getCname()+"&nbsp;"+ca.getCbrand()+"</li>");
			}
			out.println("</ul>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
